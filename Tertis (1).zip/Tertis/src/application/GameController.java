package application;


import java.io.IOException;
import java.util.Random;

import application.model.Board;
import application.model.NextBlock;
import application.model.Score;
import application.view.BoardUI;
import application.view.NextBlockUI;
import application.view.ScoreUI;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.util.Duration;

public class GameController  {
	public boolean stop;
	public float timer;
	
	private BoardUI boardUI;
	private NextBlockUI nextBlockUI;
	private ScoreUI scoreUI;
	private Board board;
	private NextBlock nextBlock;
	private Score score;
	private Timeline timeLine;
	
	@FXML
	private BorderPane pane;
	
	@FXML
    private void initialize() {
	       
	        initBoardUI();
	        initNextBlockUI();
	        initScoreUI();
	        
	        resetGame();
	        
	        timeLine = new Timeline(new KeyFrame(
	                Duration.millis(400), ae -> mainLoop()));
	        timeLine.setCycleCount(Timeline.INDEFINITE);
	        timeLine.play();
    }
	private void initBoardUI(){
		 try{
	        	FXMLLoader loader = new FXMLLoader();
	            loader.setLocation(GameController.class.getResource("view/BoardUI.fxml"));
	            AnchorPane boardPane = loader.load();
	            pane.setLeft(boardPane);
	            boardUI = loader.getController();
	            board = new Board();
	            boardUI.SetModel(board);
	            board.Attach(boardUI);
	        }catch(IOException e){
	        	e.printStackTrace();
	        }
	}
	private void initNextBlockUI(){
		 try{
	        	FXMLLoader loader = new FXMLLoader();
	            
	            loader.setLocation(GameController.class.getResource("view/NextBlockUI.fxml"));
	            AnchorPane nextBlockPane = loader.load();
	            nextBlockUI = loader.getController();
	            nextBlock = new NextBlock();
	            nextBlockUI .SetModel(nextBlock);
	            nextBlock.Attach(nextBlockUI);
	        }catch(IOException e){
	        	e.printStackTrace();
	        }
	}
	private void initScoreUI(){
		 try{
	        	FXMLLoader loader = new FXMLLoader();
	            loader.setLocation(GameController.class.getResource("view/ScoreUI.fxml"));
	            AnchorPane scorePane = loader.load();
	            scoreUI= loader.getController();
	            score = new Score();
	            scoreUI.SetModel(score);
	            score.Attach(scoreUI);
	        }catch(IOException e){
	        	e.printStackTrace();
	        }
	}
	public void resetGame(){
		stop = false;
		
		int[][] temp ;
		temp = new int[Board.WIDTH][Board.HEIGHT];
		
		for(int j = 0; j < Board.HEIGHT; j++){
			for(int i = 0; i < Board.WIDTH; i++){
				temp[i][j] = 0;
			}
		}
		
		board.SetData(temp);	// Initial board
		nextBlock.SetData(null);	// no next
		score.SetData(0);		// zero score
		
	}
	
	private void mainLoop(){
		// IF stop 
		if(stop) return;
		// 
		updateBoard();
		
		if(Input.key(KeyCode.UP)){
			System.out.println("UP Key press");
		}
		
		if(Input.key(KeyCode.Z)){
			System.out.println("Key Z press");
		}
		
		
		int[][] temp ;
		temp = new int[Board.WIDTH][Board.HEIGHT];
		
		Random ran = new Random();
		for(int j = 0; j < Board.HEIGHT; j++){
			for(int i = 0; i < Board.WIDTH; i++){
				temp[i][j] = ran.nextInt(8);
			}
		}
		
		board.SetData(temp);	// Initial board
	}
	/*/
	Block randomBlock(){
		Random ran = new Random();
		int i = ran.nextInt(7)
		switch(i){
		case 0: return ;
		case 1: return Color.BLUE;
		case 2: return Color.RED;
		case 3: return Color.YELLOW;
		case 4: return Color.GREEN;
		case 5: return Color.ORANGE;
		case 6: return Color.BROWN;
		}
		return Color.BLACK;
		
	}
	//*/
	void updateBoard(){
		
		
	}
}













