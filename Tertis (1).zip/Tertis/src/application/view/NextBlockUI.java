package application.view;

import application.Block;

public class NextBlockUI extends MyObserver{
	Block data;
	@Override
	public void Update() {
		data = (Block)model.GetData();
		showNextBlock();
	}
	public void showNextBlock(){
		// update next block UI
	}
}
