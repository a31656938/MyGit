package application.model;
import application.Block;

public class Board extends Model{
	
	public static int WIDTH = 7;
	public static int HEIGHT = 20;
	
	Block nowBlock;
	int[][] board;
	
	@Override
	public void SetData(Object data) {
		board = (int[][])data;		
		Notify();
	}

	@Override
	public Object GetData() {
		return (Object)board;
	}

}
