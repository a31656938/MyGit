package application;

public class Block {
	protected int[][] matrix;
	protected int color;
	
	public void moveLeft(){
		
	}
	
}
