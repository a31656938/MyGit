package application;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import application.model.Board;
import application.model.Model;
import application.model.NextBlock;
import application.model.Score;
import application.view.BoardUI;
import application.view.MyObserver;
import application.view.NextBlockUI;
import application.view.ScoreUI;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.util.Duration;

public class GameController  {
	public float timer;
	public ArrayList<Model> models;
	public ArrayList<MyObserver> observers;
	private Timeline timeLine;
	
	@FXML
	private BorderPane pane;
	
	@FXML
    private void initialize() {
	        
	        models = new ArrayList<Model>();
	        observers = new ArrayList<MyObserver>();
	       
	        initBoardUI();
	        initNextBlockUI();
	        initScoreUI();
	        
	        InitialGame();
	        
	        timeLine = new Timeline(new KeyFrame(
	                Duration.millis(400), ae -> mainLoop()));
	        timeLine.setCycleCount(Timeline.INDEFINITE);
	        timeLine.play();
    }
	
	private void initBoardUI(){
		 try{
	        	FXMLLoader loader = new FXMLLoader();
	            loader.setLocation(GameController.class.getResource("view/BoardUI.fxml"));
	            AnchorPane boardPane = loader.load();
	            pane.setLeft(boardPane);
	            BoardUI boardUI = loader.getController();
	            Board board = new Board();
	            boardUI.SetModel(board);
	            board.Attach(boardUI);
	            observers.add(boardUI);
	            models.add(board);
	        }catch(IOException e){
	        	e.printStackTrace();
	        }
	}
	
	private void initNextBlockUI(){
		 try{
	        	FXMLLoader loader = new FXMLLoader();
	            
	            loader.setLocation(GameController.class.getResource("view/NextBlockUI.fxml"));
	            AnchorPane nextBlockPane = loader.load();
	            NextBlockUI nextBlockUI = loader.getController();
	            NextBlock nextBlock = new NextBlock();
	            nextBlockUI .SetModel(nextBlock);
	            nextBlock.Attach(nextBlockUI);
	            observers.add(nextBlockUI);
	            models.add(nextBlock);
	        }catch(IOException e){
	        	e.printStackTrace();
	        }
	}
	
	private void initScoreUI(){
		 try{
	        	FXMLLoader loader = new FXMLLoader();
	            loader.setLocation(GameController.class.getResource("view/ScoreUI.fxml"));
	            AnchorPane scorePane = loader.load();
	            ScoreUI scoreUI= loader.getController();
	            Score score = new Score();
	            scoreUI.SetModel(score);
	            score.Attach(scoreUI);
	            observers.add(scoreUI);
	            models.add(score);
	        }catch(IOException e){
	        	e.printStackTrace();
	        }
	}
	
	public void InitialGame(){
		int[][] temp ;
		temp = new int[Board.WIDTH][Board.HEIGHT];
		
		for(int j = 0; j < Board.HEIGHT; j++){
			for(int i = 0; i < Board.WIDTH; i++){
				temp[i][j] = 0;
			}
		}
		for(int i = 0; i < Board.WIDTH; i++){
			temp[i][0] = i + 1;
		}	
		
		models.get(0).SetData(temp);	// Initial board
		models.get(1).SetData(null);	// no next
		models.get(2).SetData(0);		// zero score
		
	}
	
	private void mainLoop(){
		int[][] temp ;
		temp = new int[Board.WIDTH][Board.HEIGHT];
		
		Random ran = new Random();
		for(int j = 0; j < Board.HEIGHT; j++){
			for(int i = 0; i < Board.WIDTH; i++){
				temp[i][j] = ran.nextInt(4);
			}
		}
		
		models.get(0).SetData(temp);	// Initial board
	}
}













